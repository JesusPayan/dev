package com.mongoexample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MongoExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
