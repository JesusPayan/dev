package com.wvhotels;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WvhotelsApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
