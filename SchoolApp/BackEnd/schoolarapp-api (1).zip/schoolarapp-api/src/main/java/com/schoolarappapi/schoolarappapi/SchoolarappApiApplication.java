package com.schoolarappapi.schoolarappapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SchoolarappApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(SchoolarappApiApplication.class, args);
	}

}
