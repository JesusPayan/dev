package com.schoolarappapi.schoolarappapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SchoolarappApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
