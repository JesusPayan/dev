package com.sharecarapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShareCarApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShareCarApiApplication.class, args);
	}

}
